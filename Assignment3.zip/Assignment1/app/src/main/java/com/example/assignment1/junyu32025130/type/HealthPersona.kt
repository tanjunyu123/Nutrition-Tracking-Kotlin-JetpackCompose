package com.example.assignment1.junyu32025130.type

data class HealthPersona(
    val name: String,
    val description: String,
    val imageRes: Int // Drawable resource ID
)