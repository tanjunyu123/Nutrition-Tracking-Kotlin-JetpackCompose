package com.example.assignment1.junyu32025130.api.model

data class Nutrition(
    val calories: String,
    val fat: String,
    val sugar: String,
    val carbohydrates: String,
    val protein: String
)